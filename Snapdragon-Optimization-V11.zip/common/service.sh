#!/system/bin/sh
MODDIR=${0%/*}

# Thực thi tập lệnh của tytydraco và dự án ktweak của anh ấy, cảm ơn! 
write() {
	# Cứu trợ nếu tập tin không tồn tại
	[[ ! -f "$1" ]] && return 1
	
	# Làm cho tệp có thể ghi trong trường hợp chưa có
	chmod +w "$1" 2> /dev/null

	# Viết giá trị mới và bảo lãnh nếu có lỗi
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 30

# Adreno snapshot crashdumper
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/snapshot_crashdumper
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/dump
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/force_panic

# Adreno nền
echo "1" > /sys/module/adreno_idler/parameters/adreno_idler_active

# LPM Tắt để đi vào giấc ngủ
for lmp in /sys/module/lpm_levels/parameters; do
    write $lmp/lpm_ipi_prediction "0"
    write $lmp/lpm_prediction "0"
    write $lmp/sleep_disabled "0"
done

#Snap tweak
for gpu in /sys/class/kgsl/kgsl-3d0
do
  echo "0" > $gpu/adrenoboost
  echo "0" > $gpu/devfreq/adrenoboost
  echo "0" > $gpu/throttling
  echo "0" > $gpu/bus_split
  echo "1" > $gpu/force_clk_on
  echo "1" > $gpu/force_bus_on
  echo "1" > $gpu/force_rail_on
  echo "1" > $gpu/force_no_nap
  echo "80" > $gpu/idle_timer
  echo "0" > $gpu/max_pwrlevel
done

# Update sched up và down , cân bằng và hiệu năng cao
for gov in /sys/devices/system/cpu/*/cpufreq
  do
    echo "500" > $gov/schedutil/up_rate_limit_us
    echo "2000" > $gov/schedutil/down_rate_limit_us
    echo "85" > $gov/schedutil/hispeed_load
    echo "1" > $gov/schedutil/pl
    echo "0" > $gov/schedutil/iowait_boost_enable
  done
  
# Core ctl
for cctl in /sys/devices/system/cpu/*/core_ctl
do
  chmod 666 $cctl/enable
  echo "0" > $cctl/enable
  chmod 444 $cctl/enable
done

#Cân bằng tải CPU, thay đổi 1 thành cân bằng lõi, 2 thành cân bằng phần mềm, chỉ một phần có thể có hiệu lực do hạn chế của hệ thống , Bằng cách sửa đổi giá trị của sched_relax_domain_level, hãy mở rộng phạm vi tìm kiếm của cân bằng tải cpu và ngăn không cho hiệu suất của các lõi trong một phạm vi nhất định bị suy giảm do quá tải
echo "1" > /dev/cpuset/sched_relax_domain_level
echo "1" > /dev/cpuset/system-background/sched_relax_domain_level
echo "1" > /dev/cpuset/background/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-background/sched_relax_domain_level
echo "1" > /dev/cpuset/foreground/sched_relax_domain_level
echo "1" > /dev/cpuset/top-app/sched_relax_domain_level
echo "1" > /dev/cpuset/restricted/sched_relax_domain_level
echo "1" > /dev/cpuset/asopt/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-daemon/sched_relax_domain_level

# Cài đặt linh tính các kernel , 20 để cho ra gần như cao nhất và các tính chất khác
echo "0" > /proc/sys/kernel/sched_schedstats
echo "0" > /proc/sys/kernel/sched_boost
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo "1" > /proc/sys/kernel/timer_migration
echo "25" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "1" > /proc/sys/kernel/sched_autogroup_enabled
echo "0" > /proc/sys/kernel/sched_child_runs_first
echo "32" > /proc/sys/kernel/sched_nr_migrate

sleep 20

# kết thúc
su -lp 2000 -c "cmd notification post -S bigtext -t 'Tối ưu hoàn tất' 'Tag' 'Nếu hay hãy ủng hộ cho tác giả nhé !!'"

exit 0