#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

# Adreno Idler nền
write /sys/module/adreno_idler/parameters/adreno_idler_active 0

# LPM Tắt để đi vào giấc ngủ
for parameters in /sys/module/lpm_levels/parameters; do
    write $parameters/sleep_disabled N
    write $parameters/lpm_prediction N
    write $parameters/lpm_ipi_prediction N
done

#Snap tweak
for gpu in /sys/class/kgsl/kgsl-3d0
do
  echo "0" > $gpu/adrenoboost
  echo "0" > $gpu/devfreq/adrenoboost
  echo "N" > $gpu/adreno_idler_active
  echo "0" > $gpu/throttling
done

# Update sched up và down , cân bằng và hiệu năng cao
for gov in /sys/devices/system/cpu/*/cpufreq
  do
    echo "500" > $gov/schedutil/up_rate_limit_us
    echo "20000" > $gov/schedutil/down_rate_limit_us
    echo "90" > $gov/schedutil/hispeed_load
    echo "1" > $gov/schedutil/pl
    echo "1" > $gov/schedutil/iowait_boost_enable
  done

#Cân bằng tải CPU, thay đổi 1 thành cân bằng lõi, 2 thành cân bằng phần mềm, chỉ một phần có thể có hiệu lực do hạn chế của hệ thống , Bằng cách sửa đổi giá trị của sched_relax_domain_level, hãy mở rộng phạm vi tìm kiếm của cân bằng tải cpu và ngăn không cho hiệu suất của các lõi trong một phạm vi nhất định bị suy giảm do quá tải
echo "1" > /dev/cpuset/sched_relax_domain_level
echo "1" > /dev/cpuset/system-background/sched_relax_domain_level
echo "1" > /dev/cpuset/background/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-background/sched_relax_domain_level
echo "1" > /dev/cpuset/foreground/sched_relax_domain_level
echo "1" > /dev/cpuset/top-app/sched_relax_domain_level
echo "1" > /dev/cpuset/restricted/sched_relax_domain_level
echo "1" > /dev/cpuset/asopt/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-daemon/sched_relax_domain_level

# kernel
echo "0" > /sys/devices/system/cpu/isolated
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo "1" > /proc/sys/kernel/timer_migration
echo "0" > /proc/sys/kernel/hung_task_timeout_secs
echo "20" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "1" > /proc/sys/kernel/sched_autogroup_enabled
echo "0" > /proc/sys/kernel/sched_child_runs_first
echo "12000000" > /proc/sys/kernel/sched_wakeup_granularity_ns
echo "10000000" > /proc/sys/kernel/sched_min_granularity_ns
echo "5000000" > /proc/sys/kernel/sched_migration_cost_ns
echo "15" > /proc/sys/kernel/sched_min_task_util_for_boost
echo "32" > /proc/sys/kernel/sched_nr_migrate

# Render tốt hơn
change_task_cgroup "surfaceflinger" "top-app" "cpuset"
change_task_cgroup "surfaceflinger" "foreground" "stune"
change_task_cgroup "android.hardware.graphics.composer" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer" "foreground" "stune"
change_task_nice "surfaceflinger" "-20"
change_task_nice "android.hardware.graphics.composer" "-20"

# Tối ưu tăng tốc việc sử lý camera
change_task_affinity ".hardware." "0f"
change_task_affinity ".hardware.biometrics.fingerprint" "ff"
change_task_affinity ".hardware.camera.provider" "ff"

# Cảm biến năng lượng và ram ảo
change_task_nice "kswapd" "-2"
change_task_nice "oom_reaper" "-2"
change_task_affinity "kswapd" "7f"
change_task_affinity "oom_reaper" "7f"

# Hệ thống smooth
change_task_nice "system_server" "-18"
change_task_nice "com.android.systemui" "-18"

# Tối ưu dịch vụ Googel
change_task_nice "*google*" "0"

# kết thúc
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥Tweaks🔥' 'Tag' 'Nếu có là thành công hãy lên feedback cảm giác nha😁.'"

exit 0